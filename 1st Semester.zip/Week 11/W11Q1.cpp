#include <iostream>
using namespace std;

int main() {

    cout << "Mohammed Sarim" << endl;
    cout << "Computer Science" << endl;
    cout << "1st Year" << endl;

    return 0;
}
